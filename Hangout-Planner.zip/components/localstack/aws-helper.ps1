# LocalStack AWS CLI Helper
# Add this to your PowerShell profile or run it in your session

function awslocal {
    aws --endpoint-url=http://localhost:4566 --profile localstack @args
}

# Example usage:
# awslocal s3 ls
# awslocal s3 mb s3://my-bucket
# awslocal s3 cp file.txt s3://hangout-files/
