package main

import _ "ariga.io/atlas-provider-gorm/gormschema"
