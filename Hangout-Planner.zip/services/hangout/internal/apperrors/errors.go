package apperrors

import "errors"

// application errors
var ErrAppPortRequired = errors.New("APP_PORT is required")
var ErrDbPasswordRequired = errors.New("DB_PASSWORD required in production")

// http errors
var ErrInvalidPayload = errors.New("invalid payload")

// business errors

// auth & user
var ErrUserAlreadyExists = errors.New("user with that email already exists")
var ErrInvalidCredentials = errors.New("invalid credentials")
var ErrUserNotFound = errors.New("user not found")
var ErrUnauthorized = errors.New("Unauthorized")

//pagination error
var ErrInvalidCursorPagination = errors.New("invalid cursor pagination")

// hangout
var ErrForbidden = errors.New("forbidden")
var ErrNotFound = errors.New("resource not found")
var ErrSanitizeDescription = errors.New("failed to sanitize description")
var ErrInvalidHangoutID = errors.New("invalid hangout ID")
var ErrInvalidPagination = errors.New("invalid pagination")
var ErrInvalidActivityIDs = errors.New("one or more activity IDs are invalid or not found")

var ErrInvalidActivityID = errors.New("invalid activity ID")

// file & memory errors
var ErrInvalidMemoryID = errors.New("invalid memory ID")
var ErrTooManyFiles = errors.New("too many files")
var ErrMemoryNotFound = errors.New("memory not found")

// tls errors
var ErrLoadTLSConfig = errors.New("failed to load mTLS config")
var ErrLoadClientCert = errors.New("failed to load client certificate")
var ErrLoadCACert = errors.New("failed to load CA certificate")

// grpc errors
var ErrConnectFileService = errors.New("failed to connect to file service")
