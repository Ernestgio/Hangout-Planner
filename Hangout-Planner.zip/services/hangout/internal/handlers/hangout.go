package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/apperrors"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/constants"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/dto"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/http/request"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/http/response"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/http/sanitizer"
	"github.com/Ernestgio/Hangout-Planner/services/hangout/internal/services"
	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"gorm.io/gorm"
)

type HangoutHandler interface {
	CreateHangout(c echo.Context) error
	UpdateHangout(c echo.Context) error
	GetHangoutByID(c echo.Context) error
	DeleteHangout(c echo.Context) error
	GetHangoutsByUserID(c echo.Context) error
}

type hangoutHandler struct {
	hangoutService  services.HangoutService
	responseBuilder *response.Builder
}

func NewHangoutHandler(hangoutService services.HangoutService, responseBuilder *response.Builder) HangoutHandler {
	return &hangoutHandler{
		hangoutService:  hangoutService,
		responseBuilder: responseBuilder,
	}
}

// @Summary      Create Hangout
// @Description  Creates a new hangout for the authenticated user.
// @Tags         Hangouts
// @Accept       json
// @Produce      json
// @Param        hangout body dto.CreateHangoutRequest true "Hangout creation data"
// @Success      201 {object} response.StandardResponse{data=dto.HangoutDetailResponse} "Hangout created successfully"
// @Failure      400 {object} response.StandardResponse "Invalid request payload"
// @Failure      401 {object} response.StandardResponse "Unauthorized"
// @Failure      500 {object} response.StandardResponse "Internal server error"
// @Security     BearerAuth
// @Router       /hangouts/ [post]
func (h *hangoutHandler) CreateHangout(c echo.Context) error {
	req, err := request.BindAndValidate[dto.CreateHangoutRequest](c)
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidPayload))
	}

	sanitizedTitle := sanitizer.SanitizeString(strings.TrimSpace(req.Title))
	sanitizedDescriptionHTML, err := sanitizer.SanitizeMarkdown(*req.Description)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(apperrors.ErrSanitizeDescription))
	}

	req.Title = sanitizedTitle
	req.Description = &sanitizedDescriptionHTML

	userID := c.Get("user_id").(uuid.UUID)
	ctx := c.Request().Context()

	hangout, err := h.hangoutService.CreateHangout(ctx, userID, req)

	if err != nil {
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(err))
	}

	return c.JSON(http.StatusCreated, h.responseBuilder.Success(constants.HangoutCreatedSuccessfully, hangout))
}

// @Summary      Update Hangout
// @Description  Updates an existing hangout for the authenticated user.
// @Tags         Hangouts
// @Accept       json
// @Produce      json
// @Param        hangout_id path string true "Hangout ID"
// @Param        hangout body dto.UpdateHangoutRequest true "Hangout update data"
// @Success      200 {object} response.StandardResponse{data=dto.HangoutDetailResponse} "Hangout updated successfully"
// @Failure      400 {object} response.StandardResponse "Invalid request payload"
// @Failure      401 {object} response.StandardResponse "Unauthorized"
// @Failure      404 {object} response.StandardResponse "resource not found"
// @Failure      500 {object} response.StandardResponse "Internal server error"
// @Security     BearerAuth
// @Router       /hangouts/{hangout_id} [put]
func (h *hangoutHandler) UpdateHangout(c echo.Context) error {
	req, err := request.BindAndValidate[dto.UpdateHangoutRequest](c)
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidPayload))
	}

	sanitizedTitle := sanitizer.SanitizeString(strings.TrimSpace(req.Title))
	sanitizedDescriptionHTML, err := sanitizer.SanitizeMarkdown(*req.Description)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(apperrors.ErrSanitizeDescription))
	}

	req.Title = sanitizedTitle
	req.Description = &sanitizedDescriptionHTML

	userID := c.Get("user_id").(uuid.UUID)
	ctx := c.Request().Context()

	hangoutId, err := uuid.Parse(c.Param("hangout_id"))
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidHangoutID))
	}

	hangout, err := h.hangoutService.UpdateHangout(ctx, hangoutId, userID, req)

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return c.JSON(http.StatusNotFound, h.responseBuilder.Error(apperrors.ErrNotFound))
		}
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(err))
	}

	return c.JSON(http.StatusOK, h.responseBuilder.Success(constants.HangoutUpdatedSuccessfully, hangout))
}

// @Summary      Get Hangout by ID
// @Description  Retrieves a hangout by its ID for the authenticated user.
// @Tags         Hangouts
// @Accept       json
// @Produce      json
// @Param        hangout_id path string true "Hangout ID"
// @Success      200 {object} response.StandardResponse{data=dto.HangoutDetailResponse} "Hangout retrieved successfully"
// @Failure      400 {object} response.StandardResponse "Invalid Hangout ID"
// @Failure      401 {object} response.StandardResponse "Unauthorized"
// @Failure      404 {object} response.StandardResponse "resource not found"
// @Failure      500 {object} response.StandardResponse "Internal server error"
// @Security     BearerAuth
// @Router       /hangouts/{hangout_id} [get]
func (h *hangoutHandler) GetHangoutByID(c echo.Context) error {
	hangoutId, err := uuid.Parse(c.Param("hangout_id"))
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidHangoutID))
	}

	userID := c.Get("user_id").(uuid.UUID)
	ctx := c.Request().Context()

	hangout, err := h.hangoutService.GetHangoutByID(ctx, hangoutId, userID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return c.JSON(http.StatusNotFound, h.responseBuilder.Error(apperrors.ErrNotFound))
		}
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(err))
	}
	return c.JSON(http.StatusOK, h.responseBuilder.Success(constants.HangoutRetrievedSuccessfully, hangout))
}

// @Summary      Delete Hangout
// @Description  Deletes a hangout by its ID for the authenticated user.
// @Tags         Hangouts
// @Accept       json
// @Produce      json
// @Param        hangout_id path string true "Hangout ID"
// @Success      200 {object} response.StandardResponse "Hangout deleted successfully"
// @Failure      400 {object} response.StandardResponse "Invalid Hangout ID"
// @Failure      401 {object} response.StandardResponse "Unauthorized"
// @Failure      404 {object} response.StandardResponse "resource not found"
// @Failure      500 {object} response.StandardResponse "Internal server error"
// @Security     BearerAuth
// @Router       /hangouts/{hangout_id} [delete]
func (h *hangoutHandler) DeleteHangout(c echo.Context) error {
	hangoutId, err := uuid.Parse(c.Param("hangout_id"))
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidHangoutID))
	}

	userID := c.Get("user_id").(uuid.UUID)
	ctx := c.Request().Context()

	err = h.hangoutService.DeleteHangout(ctx, hangoutId, userID)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return c.JSON(http.StatusNotFound, h.responseBuilder.Error(apperrors.ErrNotFound))
		}
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(err))
	}
	return c.JSON(http.StatusOK, h.responseBuilder.Success(constants.HangoutDeletedSuccessfully, nil))
}

// @Summary      Get Hangouts by User ID
// @Description  Retrieves hangouts for the authenticated user with cursor-based pagination.
// @Tags         Hangouts
// @Accept       json
// @Produce      json
// @Param        pagination body dto.CursorPagination true "Pagination parameters (limit, after_id, sort_by, sort_dir)"
// @Success      200      {object}  response.StandardResponse{data=dto.PaginatedHangouts[dto.HangoutListItemResponse]} "Successfully retrieved hangouts"
// @Failure      400      {object}  response.StandardResponse "Invalid pagination parameters"
// @Failure      401      {object}  response.StandardResponse "Unauthorized"
// @Failure      500      {object}  response.StandardResponse "Internal server error"
// @Security     BearerAuth
// @Router       /hangouts/list [post]
func (h *hangoutHandler) GetHangoutsByUserID(c echo.Context) error {
	pagination, err := request.BindAndValidate[dto.CursorPagination](c)
	if err != nil {
		return c.JSON(http.StatusBadRequest, h.responseBuilder.Error(apperrors.ErrInvalidPagination))
	}

	ctx := c.Request().Context()
	userID := c.Get("user_id").(uuid.UUID)

	hangouts, err := h.hangoutService.GetHangoutsByUserID(ctx, userID, pagination)

	if err != nil {
		return c.JSON(http.StatusInternalServerError, h.responseBuilder.Error(err))
	}

	return c.JSON(http.StatusOK, h.responseBuilder.Success(constants.HangoutsRetrievedSuccessfully, hangouts))

}
