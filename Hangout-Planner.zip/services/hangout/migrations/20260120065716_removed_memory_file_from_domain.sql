-- Drop "memory_files" table
DROP TABLE `memory_files`;
